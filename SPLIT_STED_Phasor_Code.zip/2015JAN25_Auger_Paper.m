[X,Y] = meshgrid(-2:.2:2, -4:.4:4);
       Z = X .* exp(-X.^2 - Y.^2);
       surf(X,Y,Z)
plot(X);

aaa=[1 2 3; 4 5 6; 7 8 9];
bbb=[11 22; 44 55; 77 88];
ccc=[111 222 333; 444 555 666];
aaabbb=[aaa, bbb];
aaaccc=[aaa;ccc];
fprintf(aaaccc);
aaaa=zeros;
fitVar={'Amplitude1:','T1','Amplitude2','T2','Amplitude3','T3','FWHM','T0'}';
intGuessIn=inputdlg(fitVar,'Intial Guess Input',[1 40]);
intGuess=str2double(intGuessIn);
x=zeros(200,1);