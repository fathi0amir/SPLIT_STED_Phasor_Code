implay(tamstack);
saveastiff(int32(tamstack),'tamstackPoint2.tif');
saveastiff(double(tamstack),'tamstackPoint2.tif');
saveastiff(single(tamstack),'tamstackPoint3.tif');
saveastiff(single(tam2),'tamstackPoint4.tif');
saveastiff(single(tam),'pointsConv.tif');
ViewImageStack(tamstack)
for i=1:200
tam2(:,:,i)=-(tam-42)*(exp(-(i-1)/5)-exp(-(i-1)/40));
end

pointsStack02=zeros(500,500,200);
for i=1:500
for j=1:500
for k=1:200
if points(i,j)>43
pointsStack02(i,j,k)=points(i,j)*exp(-(k-1)/5)-exp(-(k-1)/40);
else
pointsStack02(i,j,k)=(points(i,j)-43)*exp(-(k-1)/25)-exp(-(k-1)/100);
end
end
end
end
saveastiff(single(pointsSupRes),'pointsSupRes.tif');
ViewImageStack(pointsNormConvDStack);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3);imshow(joy_pump_g);
figure(3);imshow(sin_par);
loadtiff('points.tif');
figure(4);imshow(points);
points=double(points);
histogram(points);
pointsReshaped=reshape(points, [1 250000]);
hist(pointsReshaped);
[value, index]=min(joy_pump_d)
max(joy_pump_d(:))
max(reshape(points, [1 500*500]))
pointsNorm=points/(max(points(:)));


pointsNormConvGStack=zeros(500,500,200);
for i=1:500
for j=1:500
for k=1:200
pointsNormConvGStack(i,j,k)=pointsNormConvG(i,j)*(exp(-(k-1)/50)-exp(-(k-1)/5));
end
end
end

pointsNormConvG=imfilter(pointsNorm, joy_pump_g);
imtool(pointsNormConvD)

%Determine the midpoint of the gaussian convoluted with donut convolted
%coordinate and value
k=1;
for i=1:500
    for j=1:500
        dataFloor=pointsNormConvG(i,j)-pointsNormConvD(i,j);
        if dataFloor~=0
            if floor(dataFloor*100000)==0
            coordEq(k,1)=i;
            coordEq(k,2)=j;
            coordEq(k,3)=pointsNormConvG(i,j);
            k=k+1;
            end
        end
    end
end

%generate stack of super resolution addition (not subtraction) with
%different time profile if there are bigger than the overlapping value or
%not
for i=1:500
for j=1:500
for k=1:200
    pointsSupResAdd2(i,j)=pointsNormConvG(i,j)+pointsNormConvD(i,j);
    if pointsNormConvG(i,j)>coordEq(1,3)
        pointsSupResAdd2Stack(i,j,k)=pointsSupResAdd2(i,j)*(exp(-(k-1)/50)-exp(-(k-1)/5));
    else
        pointsSupResAdd2Stack(i,j,k)=pointsSupResAdd2(i,j)*(exp(-(k-1)/80)-exp(-(k-1)/3));
    end
end
end
end
saveastiff(single(pointsSupResAdd2Stack),'pointsSupResAdd2Stack.tif')

for i=1:200
pointsSupRes(:,:,i)=pointsNormConvGStack(:,:,i)-10*pointsNormConvDStack(:,:,i);
end
saveastiff(single(pointsSupResAdd),'pointsSupResAdd.tif');
max(pointsSupRes(:))


for i=1:200
pointsSupResAdd(:,:,i)=pointsNormConvGStack(:,:,i)+pointsNormConvDStack(:,:,i);
end
min(pointsNormConvDStack(:))

t=0:199;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:500 %Calculate the Real Part
for j=1:500
pointsSupResAdd2StackFr=squeeze(pointsSupResAdd2Stack(i,j,:));pointsSupResAdd2StackFrT=pointsSupResAdd2StackFr.';
pointsSupResAdd2StackRe(i,j)=sum(pointsSupResAdd2StackFrT.*cos(2*pi*t/200))/abs(sum(pointsSupResAdd2StackFrT));
if isnan(pointsSupResAdd2StackRe(i,j))
pointsSupResAdd2StackRe(i,j)=0;
end
end
end

for i=1:500 %Calculate the imaginary part
for j=1:500
pointsSupResAdd2StackFr=squeeze(pointsSupResAdd2Stack(i,j,:));pointsSupResAdd2StackFrT=pointsSupResAdd2StackFr.';
pointsSupResAdd2StackIm(i,j)=sum(pointsSupResAdd2StackFrT.*sin(2*pi*t/200))/abs(sum(pointsSupResAdd2StackFrT));
if isnan(pointsSupResAdd2StackIm(i,j))
pointsSupResAdd2StackIm(i,j)=0;
end
end
end

%Determine the end point between the two end of phase plot related to two
%temporal profile involved
[pointsSupResAdd2StackReMax,pointsSupResAdd2StackReMaxInd] = max(pointsSupResAdd2StackRe(:));
[indRowMax, indColMax] = ind2sub(size(pointsSupResAdd2StackRe),pointsSupResAdd2StackReMaxInd);
pointsSupResAdd2StackImMax=pointsSupResAdd2StackIm(indRowMax,indColMax);
[pointsSupResAdd2StackReMin,pointsSupResAdd2StackReMinInd] = min(pointsSupResAdd2StackRe(:));
[indRowMin, indColMin] = ind2sub(size(pointsSupResAdd2StackRe),pointsSupResAdd2StackReMinInd);
pointsSupResAdd2StackImMin=pointsSupResAdd2StackIm(indRowMin,indColMin);

plot(pointsSupResAddIm,pointsSupResAddRe);

%Calculate the time integrated intensity
for i=1:500
for j=1:500
pointsSupResAdd2StackSum(i,j)=sum(pointsSupResAdd2Stack(i,j,:));
end
end

%N1=[M11^-1*g+M12^-1*s]N Going back to image from the reciprocal space
pointsSupResAdd2StackPhas2ImageMax=(pointsSupResAdd2StackRe./pointsSupResAdd2StackReMax+pointsSupResAdd2StackIm./pointsSupResAdd2StackImMax).*pointsSupResAdd2StackSum;
pointsSupResAdd2StackPhas2ImageMin=(pointsSupResAdd2StackRe./pointsSupResAdd2StackReMin+pointsSupResAdd2StackIm./pointsSupResAdd2StackImMin).*pointsSupResAdd2StackSum;

for i=1:500
    for j=1:500
   plot(pointsSupResAddRe(i,j),pointsSupResAddIm(i,j),'o'); 
   hold on
    end
end


imtool(pointsSupResAdd2StackPhas2ImageMax);


