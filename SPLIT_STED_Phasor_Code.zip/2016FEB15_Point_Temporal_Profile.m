implay(tamstack);
saveastiff(int32(tamstack),'tamstackPoint2.tif');
saveastiff(double(tamstack),'tamstackPoint2.tif');
saveastiff(single(tamstack),'tamstackPoint3.tif');
saveastiff(single(tam2),'tamstackPoint4.tif');
saveastiff(single(tam),'pointsConv.tif');
ViewImageStack(tamStack2)
pointsNormConvDStack=loadtiff('pointsNormConvDStack.tif');
imtool(pointsNorm);
for i=1:200
tam2(:,:,i)=-(tam-42)*(exp(-(i-1)/5)-exp(-(i-1)/40));
end

pointsStack02=zeros(500,500,200);
for i=1:500
for j=1:500
for k=1:200
if points(i,j)>43
pointsStack02(i,j,k)=points(i,j)*exp(-(k-1)/5)-exp(-(k-1)/40);
else
pointsStack02(i,j,k)=(points(i,j)-43)*exp(-(k-1)/25)-exp(-(k-1)/100);
end
end
end
end
saveastiff(single(pointsSupRes),'pointsSupRes.tif');
ViewImageStack(pointsNormConvDStack);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3);imshow(joy_pump_g);
figure(3);imshow(sin_par);
loadtiff('points.tif');
figure(4);imshow(points);
points=double(points);
histogram(points);
pointsReshaped=reshape(points, [1 250000]);
hist(pointsReshaped);
[value, index]=min(joy_pump_d)
max(joy_pump_d(:))
max(reshape(points, [1 500*500]))
pointsNorm=points/(max(points(:)));
points=double(points);

pointsNormConvGStack=zeros(500,500,200);
for i=1:500
for j=1:500
for k=1:200
pointsNormConvGStack(i,j,k)=pointsNormConvG(i,j)*(exp(-(k-1)/50)-exp(-(k-1)/5));
end
end
end

pointsNorm=points/(max(points(:)));

pointsNormConvG=imfilter(pointsNorm, joy_pump_g);
imtool(pointsNormConvG)

pointsNormConvD=imfilter(pointsNorm, joy_pump_d);
imtool(pointsNormConvD)

for i=1:500
    for j=1:500
        for k=1:200
            
            pointsNormConvGSt(i,j,k)=pointsNormConvG(i,j)*(exp(-(k-1)/50)-exp(-(k-1)/5));
            pointsNormConvDSt(i,j,k)=pointsNormConvD(i,j)*(exp(-(k-1)/10)-exp(-(k-1)/1));
        end
    end
end
ViewImageStack(pointsNormConvGSt)
ViewImageStack(pointsNormConvDSt)
imtool(pointsNormConvDSt(:,:,3))

plot(t, squeeze(pointsNormConvDSt(222,222,:)))


for i=1:200
    pnNrmCnvSmSt(:,:,i)=pointsNormConvGSt(:,:,i)+pointsNormConvDSt(:,:,i);    
end
ViewImageStack(pnNrmCnvSmSt)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pnNrmCnvSmStRe=zeros(500);
pnNrmCnvSmStIm=zeros(500);
for i=1:500 %Calculate the Real & Imaginary Part
    for j=1:500
        pnNrmCnvSmStRe(i,j)=sum(squeeze(pnNrmCnvSmSt(i,j,:)).'.*cos(2*pi*t/200))/abs(sum(squeeze(pnNrmCnvSmSt(i,j,:)).'));
        pnNrmCnvSmStIm(i,j)=sum(squeeze(pnNrmCnvSmSt(i,j,:)).'.*sin(2*pi*t/200))/abs(sum(squeeze(pnNrmCnvSmSt(i,j,:)).'));
        if isnan(pnNrmCnvSmStRe(i,j))
            pnNrmCnvSmStRe(i,j)=0;
        end
        if isnan(pnNrmCnvSmStIm(i,j))
            pnNrmCnvSmStIm(i,j)=0;
        end
    end
end

pnNrmCnvSmStIm=zeros(500);
for i=1:500 %Calculate the imaginary Part
    for j=1:500
        pnNrmCnvSmStIm(i,j)=sum(squeeze(pointsNormConvDSt(i,j,:)).'.*sin(2*pi*t/200))/abs(sum(squeeze(pointsNormConvDSt(i,j,:)).'));
        if isnan(pnNrmCnvSmStIm(i,j))
            pnNrmCnvSmStIm(i,j)=0;
        end
    end
end

for i=1:500
   
       plot(pnNrmCnvSmStRe(:,i), pnNrmCnvSmStIm(:,i),'.r');
       hold on;
  
end

pnNrmCnvSmStZ=pnNrmCnvSmStRe+j*pnNrmCnvSmStIm;

for i=1:500
    for j=1:500
        plot(pnNrmCnvSmStZ(i,j));
        hold on;
    end
end


[pnNrmCnvSmStReMx,pnNrmCnvSmStReInd]=max(pnNrmCnvSmStRe(:));

pnNrmCnvSmStImMx=pnNrmCnvSmStIm(pnNrmCnvSmStReInd);

for i=1:500
    for j=1:500
        pnNrmCnvSmStSum(i,j)=sum(pnNrmCnvSmSt(i,j,:));
    end
end

pnNrmCnvSmStMx=(pnNrmCnvSmStRe./pnNrmCnvSmStReMx+pnNrmCnvSmStIm./pnNrmCnvSmStImMx).*pnNrmCnvSmStSum;

imtool(pnNrmCnvSmStMx)
figure; imtool(pointsNormConvG)

[pnNrmCnvSmStMnrow,pnNrmCnvSmStMncol] = find(abs(pnNrmCnvSmStRe-0.2132)<0.00003)

pnNrmCnvSmStReMn=pnNrmCnvSmStRe(pnNrmCnvSmStMnrow,pnNrmCnvSmStMncol);
pnNrmCnvSmStImMn=pnNrmCnvSmStIm(pnNrmCnvSmStMnrow,pnNrmCnvSmStMncol);

pnNrmCnvSmStMn=(pnNrmCnvSmStRe./pnNrmCnvSmStReMn+pnNrmCnvSmStIm./pnNrmCnvSmStImMn).*pnNrmCnvSmStSum;
figure; imtool(pnNrmCnvSmStMn)

min(pnNrmCnvSmStRe(find(pnNrmCnvSmStRe>0))) %to find minimum greater than zero
[row, col, val]=find(abs(pnNrmCnvSmStRe)>0.0001)
figure
pointsSupResAdd2StackPhas2ImageMax=(pointsSupResAdd2StackRe./pointsSupResAdd2StackReMax+pointsSupResAdd2StackIm./pointsSupResAdd2StackImMax).*pointsSupResAdd2StackSum;


for i=1:500 %Calculate the imaginary part
    for j=1:500
        pointsSupResAdd2StackFr=squeeze(pointsSupResAdd2Stack(i,j,:));pointsSupResAdd2StackFrT=pointsSupResAdd2StackFr.';
        pointsSupResAdd2StackIm(i,j)=sum(pointsSupResAdd2StackFrT.*sin(2*pi*t/200))/abs(sum(pointsSupResAdd2StackFrT));
        if isnan(pointsSupResAdd2StackIm(i,j))
            pointsSupResAdd2StackIm(i,j)=0;
        end
    end
end



%Determine the midpoint of the gaussian convoluted with donut convolted
%coordinate and value
k=1;
for i=1:500
    for j=1:500
        dataFloor=pointsNormConvG(i,j)-pointsNormConvD(i,j);
        if dataFloor~=0
            if floor(dataFloor*100000)==0
            coordEq(k,1)=i;
            coordEq(k,2)=j;
            coordEq(k,3)=pointsNormConvG(i,j);
            k=k+1;
            end
        end
    end
end

%generate stack of super resolution addition (not subtraction) with
%different time profile if there are bigger than the overlapping value or
%not
for i=1:500
for j=1:500
for k=1:200
    pointsSupResAdd2(i,j)=pointsNormConvG(i,j)+pointsNormConvD(i,j);
    if pointsNormConvG(i,j)>coordEq(1,3)
        pointsSupResAdd2Stack(i,j,k)=pointsSupResAdd2(i,j)*(exp(-(k-1)/50)-exp(-(k-1)/5));
    else
        pointsSupResAdd2Stack(i,j,k)=pointsSupResAdd2(i,j)*(exp(-(k-1)/80)-exp(-(k-1)/3));
    end
end
end
end


saveastiff(single(pointsSupResAdd2Stack),'pointsSupResAdd2Stack.tif')

for i=1:200
pointsSupRes(:,:,i)=pointsNormConvGStack(:,:,i)-10*pointsNormConvDStack(:,:,i);
end
saveastiff(single(pointsSupResAdd),'pointsSupResAdd.tif');
max(pointsSupRes(:))


for i=1:200
pointsSupResAdd(:,:,i)=pointsNormConvGStack(:,:,i)+pointsNormConvDStack(:,:,i);
end
min(pointsNormConvDStack(:))

t=0:199;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:500 %Calculate the Real Part
for j=1:500
pointsSupResAdd2StackFr=squeeze(pointsSupResAdd2Stack(i,j,:));pointsSupResAdd2StackFrT=pointsSupResAdd2StackFr.';
pointsSupResAdd2StackRe(i,j)=sum(pointsSupResAdd2StackFrT.*cos(2*pi*t/200))/abs(sum(pointsSupResAdd2StackFrT));
if isnan(pointsSupResAdd2StackRe(i,j))
pointsSupResAdd2StackRe(i,j)=0;
end
end
end

for i=1:500 %Calculate the imaginary part
for j=1:500
pointsSupResAdd2StackFr=squeeze(pointsSupResAdd2Stack(i,j,:));pointsSupResAdd2StackFrT=pointsSupResAdd2StackFr.';
pointsSupResAdd2StackIm(i,j)=sum(pointsSupResAdd2StackFrT.*sin(2*pi*t/200))/abs(sum(pointsSupResAdd2StackFrT));
if isnan(pointsSupResAdd2StackIm(i,j))
pointsSupResAdd2StackIm(i,j)=0;
end
end
end

%Determine the end point between the two end of phase plot related to two
%temporal profile involved
[pointsSupResAdd2StackReMax,pointsSupResAdd2StackReMaxInd] = max(pointsSupResAdd2StackRe(:));
[indRowMax, indColMax] = ind2sub(size(pointsSupResAdd2StackRe),pointsSupResAdd2StackReMaxInd);
pointsSupResAdd2StackImMax=pointsSupResAdd2StackIm(indRowMax,indColMax);
[pointsSupResAdd2StackReMin,pointsSupResAdd2StackReMinInd] = min(pointsSupResAdd2StackRe(:));
[indRowMin, indColMin] = ind2sub(size(pointsSupResAdd2StackRe),pointsSupResAdd2StackReMinInd);
pointsSupResAdd2StackImMin=pointsSupResAdd2StackIm(indRowMin,indColMin);

plot(pointsSupResAddIm,pointsSupResAddRe);

%Calculate the time integrated intensity
for i=1:500
for j=1:500
pointsSupResAdd2StackSum(i,j)=sum(pointsSupResAdd2Stack(i,j,:));
end
end

%N1=[M11^-1*g+M12^-1*s]N Going back to image from the reciprocal space
pointsSupResAdd2StackPhas2ImageMax=(pointsSupResAdd2StackRe./pointsSupResAdd2StackReMax+pointsSupResAdd2StackIm./pointsSupResAdd2StackImMax).*pointsSupResAdd2StackSum;
pointsSupResAdd2StackPhas2ImageMin=(pointsSupResAdd2StackRe./pointsSupResAdd2StackReMin+pointsSupResAdd2StackIm./pointsSupResAdd2StackImMin).*pointsSupResAdd2StackSum;

for i=1:500
    for j=1:500
   plot(pointsSupResAddRe(i,j),pointsSupResAddIm(i,j),'o'); 
   hold on
    end
end


imtool(pointsSupResAdd2StackPhas2ImageMax);


