points=points/max(points(:));
for i=1:200
png(:,:,i)=points*(exp(-(i-1)/100)-exp(-(i-1)/5));
end
for i=1:200
pnd(:,:,i)=points*(exp(-(i-1)/30)-exp(-(i-1)/1));
end

for i=1:200
   plot(i, sum(reshape(pnd(:,:,i), numel(pnd(:,:,i)), 1))/numel(pndCnv(:,:,i)), '.g')
   hold on
end


ViewImageStack(pnCnvSm);

for i=1:200
pndCnv(:,:,i)=imfilter(pnd(:,:,i), joy_pump_d);
end
for i=1:200
pngCnv(:,:,i)=imfilter(png(:,:,i), joy_pump_g);
end

for i=1:200
pnCnvSm(:,:,i)=pndCnv(:,:,i)+pngCnv(:,:,i);
end

pnCnvSmRe=zeros(500);
pnCnvSmIm=zeros(500);
for i=1:500 %Calculate the Real & Imaginary Part
    for j=1:500
        pnCnvSmRe(i,j)=sum(squeeze(pnCnvSm(i,j,:)).'.*cos(2*pi*t/200))/abs(sum(squeeze(pnCnvSm(i,j,:)).'));
        pnCnvSmIm(i,j)=sum(squeeze(pnCnvSm(i,j,:)).'.*sin(2*pi*t/200))/abs(sum(squeeze(pnCnvSm(i,j,:)).'));
        if isnan(pnCnvSmRe(i,j))
            pnCnvSmRe(i,j)=0;
        end
        if isnan(pnCnvSmIm(i,j))
            pnCnvSmIm(i,j)=0;
        end
    end
end

for i=1:500
   
       plot(pnCnvSmRe(:,i), pnCnvSmIm(:,i),'.r');
       hold on;
  
end

for i=1:500
    
    
    hist3([pnCnvSmRe(:,i), pnCnvSmIm(:,i)],[20 20]);
    hold on;
    set(gcf,'renderer','opengl');
    set(get(gca,'child'),'FaceColor','interp','CDataMode','auto');
end



     