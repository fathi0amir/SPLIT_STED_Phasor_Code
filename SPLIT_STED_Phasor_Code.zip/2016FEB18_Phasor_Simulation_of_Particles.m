sPn=zeros(64);
sPn(32,16)=1;
sPn(32,48)=1;

k=1;
for i=1:64
    for j=1:64
        if sPn(i,j)==1
           pnInd(k,1)=i;
           pnInd(k,2)=j;
           k=k+1;
        end
    end
end
size(pnInd, 1)


imtool(sPnGs)

%Define constants
sgnCnt=100000; %maximum counts
bmWst=167; %Beam waist
tau0=2.5; %lifetime
gamma0=1/tau0;
kSat=10; %I_STED/I_Saturation Ratio

for i=1:64
    for j=1:64
        r=sqrt((pnInd(1,1)-i)^2+(pnInd(1,2)-j)^2)*5.2;
        sPnGs1(i,j)=...
            sgnCnt*exp(-2*r^2/bmWst^2);
    end
end

for i=1:64
    for j=1:64
        r=sqrt((pnInd(2,1)-i)^2+(pnInd(2,2)-j)^2)*5.2;
        
        sPnGs2(i,j)=...
            sgnCnt*exp(-2*r^2/bmWst^2);
    end
end

sPnGs=sPnGs1+sPnGs2;

imtool(sPnGs)


for i=1:64
    for j=1:64
        r=sqrt((pnInd(1,1)-i)^2+(pnInd(1,2)-j)^2)*5.2;
        gamma(i,j)=gamma0*(1+kSat*r^2/bmWst^2);
        sPnDn1(i,j)=...
            sgnCnt*exp(-2*r^2/bmWst^2)*...
            exp(-gamma(i,j)*tm);
    end
end

for i=1:64
    for j=1:64
        r=sqrt((pnInd(2,1)-i)^2+(pnInd(2,2)-j)^2)*5.2;
        gamma(i,j)=gamma0*(1+kSat*r^2/bmWst^2);
        sPnDn2(i,j)=...
            sgnCnt*exp(-2*r^2/bmWst^2)*...
            exp(-gamma(i,j)*tm);
    end
end

sPnDn=sPnDn1+sPnDn2;

imtool(sPnDn)

plot(sPnDn(32,:));

sPn=zeros(64);
for i=1:64
    for j=1:64
       if rand()>0.999
           sPn(i,j)=1;
       end
    end
    
end

pnInd=0;
k=1;
for i=1:64
    for j=1:64
        if sPn(i,j)==1
           pnInd(k,1)=i;
           pnInd(k,2)=j;
           k=k+1;
        end
    end
end


sPnDn=zeros(64,64,128);
tm=0;
for t=1:128
   tm=(t-1)*12.5/128;
    for k=1:size(pnInd,1)
        for i=1:64
            for j=1:64
                r=sqrt((pnInd(k,1)-i)^2+(pnInd(k,2)-j)^2)*5.2;
                gamma(i,j)=gamma0*(1+kSat*r^2/bmWst^2);
                sPnDnTemp(i,j,t)=...
                    sgnCnt*exp(-2*r^2/bmWst^2)*...
                    exp(-gamma(i,j)*tm);
                sPnDn(i,j,t)=sPnDn(i,j,t) + sPnDnTemp(i,j,t);
            end
        end
    end
end


ViewImageStack(sPnDn);
imtool(sPnDn(:,:,78));


sPnDnRe=zeros(64);
sPnDnIm=zeros(64);

for i=1:64
   for j=1:64
       realpart=real(fft(squeeze(sPnDn(i,j,:))));
       imagpart=imag(fft(squeeze(sPnDn(i,j,:))));
       sPnDnRe(i,j)=realpart(2)/abs(sum(squeeze(sPnDn(i,j,:))));
       sPnDnIm(i,j)=imagpart(2)/abs(sum(squeeze(sPnDn(i,j,:))));
   end
end

sPnDnRe(51,6)=real(fft(squeeze(sPnDn(51,6,:))))/abs(sum(squeeze(sPnDn(51,6,:))));
plot(squeeze(sPnDn(51,6,:)))
abs(sum(squeeze(sPnDn(51,6,:))))

for i=1:64
   
       plot(sPnDnRe(:,i), sPnDnIm(:,i),'.r');
       hold on;
      
  
end

for t=1:128
time(t)=(t-1)*12.5/128;
end

plot(time, squeeze(sPnDn(50,42,:))/max(sPnDn(50,42,:)));
hold on


sPnDnRe=zeros(64);
sPnDnIm=zeros(64);
for i=1:64 %Calculate the Real & Imaginary Part
    for j=1:64
        sPnDnRe(i,j)=sum(squeeze(sPnDn(i,j,:)).'.*cos(2*pi*time/12.5))/abs(sum(squeeze(sPnDn(i,j,:)).'));
        sPnDnIm(i,j)=sum(squeeze(sPnDn(i,j,:)).'.*sin(2*pi*time/12.5))/abs(sum(squeeze(sPnDn(i,j,:)).'));
        if isnan(sPnDnRe(i,j))
            sPnDnRe(i,j)=0;
        end
        if isnan(sPnDnIm(i,j))
            sPnDnIm(i,j)=0;
        end
    end
end

for i=1:64
    for j=1:64
        sPnDnSm(i,j)=sum(sPnDn(i,j,:));
    end
end

imgMx=(sPnDnRe/0.9981-sPnDnIm/0.03308).*sPnDnSm;
imgMn=(sPnDnRe/0.4053-sPnDnIm/0.4773).*sPnDnSm;


trapz