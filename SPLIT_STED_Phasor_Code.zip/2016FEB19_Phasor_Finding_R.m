%Define constants
sgnCnt=100000; %maximum counts
bmWst=167; %Beam waist
tau0=2.5; %lifetime
gamma0=1/tau0;
kSat=10; %I_STED/I_Saturation Ratio
nCmp=3; %number of component
%temporal steps
time=linspace(0,21.5,128);

%intesity function 
intst=@(time,r1,r2, gamma0, kSat, bmWst)(exp(-gamma0*time)./(1+kSat*gamma0*time/2).*...
    (exp(-(1+kSat*gamma0*time/2)*2*r1^2/bmWst^2)-...
     exp(-(1+kSat*gamma0*time/2)*2*r2^2/bmWst^2))...
    );

rBndTmp=0;
for k=1:nCmp-1
    for i=1:40
        r1=rBndTmp;
        r2=r1+(i-1)*5.2;
        intstInt(i)=trapz(time, intst(time,r1,r2, gamma0, kSat, bmWst)-...
            (1/nCmp)*intst(time,0,10000, gamma0, kSat, bmWst)...
            );
    end
    [rMnVl rMnInd]=min(abs(intstInt));
    rBnd(k)=rBndTmp+rMnInd*5.2;
    rBndTmp=rBnd(k);
end


[rMnVl rMnInd]=min(abs(intstInt));
rBnd=rMnInd*5.2

clear('i','rr');

plot(abs(inststInt))



