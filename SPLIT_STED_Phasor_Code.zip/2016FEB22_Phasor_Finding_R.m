%Define constants
sgnCnt=100000; %maximum counts
bmWst=167; %Beam waist
tau0=2.5; %lifetime
gamma0=1/tau0;
kSat=10; %I_STED/I_Saturation Ratio
nCmp=6; %number of component
rPxSz=0.01; %Pixel size
imSz=64; %Image size
tmMx=12.5;%Maximum time interval
nTmLp=128;%number of time laps 


%temporal steps
time=linspace(0,tmMx,nTmLp);

%intesity function 
intst=@(time,r1,r2, gamma0, kSat, bmWst)(exp(-gamma0*time)./(1+kSat*gamma0*time/2).*...
    (exp(-(1+kSat*gamma0*time/2)*2*r1^2/bmWst^2)-...
     exp(-(1+kSat*gamma0*time/2)*2*r2^2/bmWst^2))...
    );
%find the r when int(F, r1:r2)=int(f, 0, inf)/(number of components)
rBndTmp=0; rBnd=0; rBnd(1)=0;
for k=1:nCmp-1
    for i=1:floor(bmWst/rPxSz)
        r1=rBndTmp;
        r2=r1+(i-1)*rPxSz;
        intstInt(i)=trapz(time, intst(time,r1,r2, gamma0, kSat, bmWst))-...
            (1/nCmp)*trapz(time, intst(time,0,inf, gamma0, kSat, bmWst));
    end
    [rMnVl rMnInd]=min(abs(intstInt));
    rBnd(k+1)=rBndTmp+rMnInd*rPxSz;
    rBndTmp=rBnd(k+1);
end
rBnd(end+1)=inf;
clear('k', 'i', 'rBndTmp', 'r1', 'r2', 'rMnInd', 'rMnVl','intstInt')

% trapz(time, intst(time,0,31.2, gamma0, kSat, bmWst))

% [rMnVl rMnInd]=min(abs(intstInt));
% % rBnd=rMnInd*5.2

% clear('i','rr');

% plot(abs(inststInt))



