%Define constants
sgnCnt=100000; %maximum counts
bmWst=167; %Beam waist
tau0=2.5; %lifetime
gamma0=1/tau0;
kSat=1; %I_STED/I_Saturation Ratio
nCmp=3; %number of component
nHrm=1; %number of harmonics
pxSz=5.2; %Pixel Size

%temporal steps
time=linspace(0,12.5,128);
% for t=1:128
% time(t)=(t-1)*12.5/128;
% end
% clear('t');

%Generate only two particle in the center with the certain distance
sPn=zeros(64);
sPn(32, 23)=1;
sPn(32, 43)=0;

%Generate random particles
sPn=zeros(64);
for i=1:64
    for j=1:64
        if rand()>0.9991
            sPn(i,j)=1;
        end
    end
end
clear('i','j')

%count the number of particles in the simulated image
pnInd=0;
k=1;
for i=1:64
    for j=1:64
        if sPn(i,j)==1
            pnInd(k,1)=i;
            pnInd(k,2)=j;
            k=k+1;
        end
    end
end
clear('k','i','j')

%Convolution function
cnvFn=@(gamma0, kSat, r1, r2, bmWstsgnCnt,time)...
    exp(-gamma0*time).*1/(1+kSat*gamma0*time/2).*...
    exp(-(1+kSat*gamma0*time/2)*2*r1^2/bmWst^2)-...
    exp(-(1+kSat*gamma0*time/2)*2*r1^2/bmWst^2)

%Convolution part, creates a stack of temporal spatial convolution of the
%image
sPnSted=zeros(64,64,128);
sPnStedTemp=zeros(64,64,128);
for t=1:128
    for k=1:size(pnInd,1)
        for i=1:64
            for j=1:64
                r=sqrt((pnInd(k,1)-i)^2+(pnInd(k,2)-j)^2)*pxSz;
                for l=1:nCmp
                    if (r>=rBnd(l))&&(r<=rBnd(l+1))
                        sPnStedTemp(i,j,t)=...
                            sgnCnt*exp(-2*r^2/bmWst^2)*...
                            exp(-gamma0*(1+kSat*r^2/bmWst^2)*time(t))*...
                            exp(-gamma0*time(t))*(1/(1+kSat*time(t)/2))*...
                            (exp(-(1+kSat*gamma0*time(t)/2)*2*rBnd(l)^2/bmWst^2)-...
                            exp(-(1+kSat*gamma0*time(t)/2)*2*rBnd(l+1)^2/bmWst^2));
                    end
                end
            end
        end
        sPnSted(:,:,t)=sPnSted(:,:,t) + sPnStedTemp(:,:,t);
    end
end
clear('sPnStedTemp','t','k','i','j','r','l');

%View the generated stack
ViewImageStack(sPnSted)

(exp(-(1+kSat*gamma0*time(5)/2)*2*rBnd(2)^2/bmWst^2)-...
    exp(-(1+kSat*gamma0*time(5)/2)*2*rBnd(1+1)^2/bmWst^2))

%calculate the real part and imaginary part of temeporal profile
%the 3rd dimentions indexes the higher harmonics of the fuorier transform.
sPnStedRe=zeros(64,64,128);
sPnStedIm=zeros(64,64,128);
for k=1:nHrm
    for i=1:64
        for j=1:64
            rePrt=real(fft(squeeze(sPnSted(i,j,:))));
            imPrt=imag(fft(squeeze(sPnSted(i,j,:))));
            sPnStedRe(i,j,k)=rePrt(k+1)/abs(sum(squeeze(sPnSted(i,j,:))));
            sPnStedIm(i,j,k)=imPrt(k+1)/abs(sum(squeeze(sPnSted(i,j,:))));
        end
    end
end
clear('rePrt','imPrt','i','j','k');

%pxTmPrf=Pixel Temporal Profile
%grnd: Integrand 
%calculate the real part and imaginary part of temeporal profile by using
%analytical Sine and Cosine NOT FFT.
for i=1:64
   for j=1:64
       pxTmPrf=squeeze(sPnSted(i,j,:)).';
       grndRe=pxTmPrf.*cos(2*pi*time/max(time));
       grndIm=pxTmPrf.*sin(2*pi*time/max(time));
       sPnStedRe(i,j)=trapz(time, grndRe)/trapz(time,pxTmPrf);
       sPnStedIm(i,j)=trapz(time, grndIm)/trapz(time,pxTmPrf);
   end
end
clear('pxTmPrf','grndRe','grndIm')

%Plot the imaginary part vs the Real part (Phasor Plot)
for i=1:64
    plot(sPnStedRe(:,i,1), sPnStedIm(:,i,1),'.b');
    hold on;
end
clear('i');


%Temporal average 
for i=1:64
    for j=1:64
        sPnDnSm(i,j)=sum(sPnSted(i,j,:));
    end
end
clear('i','j')

%time integrated intensity
for i=1:64
    for j=1:64
        pxTmPrf=squeeze(sPnSted(i,j,:)).';
        sPnStedInt(i,j)=trapz(time,pxTmPrf);
    end
end
clear('i','j','pxTmPrf')

%Matrix M for the known number of component in the temporal dynamics
%[g1   g2   g3   ...]
%[s1   s2   s3   ...]
%[g1h2 g2h2 g3h2 ...]
%[s1h2 s2h2 s3h2 ...]
%....
%g=real part, s1=imaginary part
mtrx=[0.464 0.995;-0.453 -0.053];%This one is selected by choosing the 
%two end of the phasor plot
mtrx=[sPnStedRe(9,40,1) sPnStedRe(9,20,1);...
    sPnStedIm(9,40,1) sPnStedIm(9,20,1)]%this one is selected by selecting 
%the very center of the simulated particle and the rime of the dounut
mtrxInv=inv(mtrx);

%Vector P made of real and imaginary parts of various harmonics 
%[g   s   gh2   sh2 ...] every element of this vector is an image in
%reciprocal space
for i=1:nHrm
    phsr(2*i-1,:,:)=sPnStedRe(:,:,i);
    phsr(2*i,:,:)=sPnStedIm(:,:,i);
end

%Reconstructing the images related to each component
for k1=1:2*nHrm
    for k2=1:2*nHrm
        sPnStedRc(k1,:,:)=mtrxInv(k1,k2).*squeeze(phsr(k2,:,:)).*sPnStedInt;
    end
end
clear('k1','k2')

imtool(squeeze(sPnStedRc(1,:,:)))
imtool(squeeze(sPnStedRc(2,:,:)))

ViewImageStack(sPnSted);
