%sPnStedRe and sPnStedIm are the real part and imaginary part of the phasor
%af the foriour transform.

%Determin the min and max of the phasor data points for only the first
%harmonics 
minRe=min(min(sPnStedRe(:,:,2)));
maxRe=max(max(sPnStedRe(:,:,2)));
minIm=min(min(sPnStedIm(:,:,2)));
maxIm=max(max(sPnStedIm(:,:,2)));

%reshape the data points of the first harmonics in 1D array
%and concatenate them to form m-x-2 array with first column
%as real paarts and second column as imaginary part
rePrt=reshape(sPnStedRe(:,:,2),[iniPrm.imSz^2,1]);
imPrt=reshape(sPnStedIm(:,:,2),[iniPrm.imSz^2,1]);
imRePrt=[rePrt, imPrt];

%record the intensities in the hist3 handler
intCnt = hist3(imRePrt, [64,64]);%increase the number of bin to 64by64
intCntT = intCnt';
intCntT(size(intCnt,1) + 1, size(intCnt,2) + 1) = 0; %add zero to the data points

%determine the boundaries from min to max in equal spacing
reBnd = linspace(minRe,maxRe,size(intCnt,1)+1);
imBnd = linspace(minIm,maxIm,size(intCnt,1)+1);

%the following plots the 3D histogram with the two the intensity map
%if only the "pcolor" part the executed the result is the intesity map
%only. "edgecolor', 'none'" is to remove the grids in this plot mode
%"'FaceColor','interp','CDataMode','auto'" is to make the 
%follow the intensity colormap. "'FaceAlpha',.65" is for transparency
%purpose. adding ZData to pcolor is to separate the two plot from 
%each other when put together 
hist3(imRePrt, [iniPrm.imSz,iniPrm.imSz],'FaceAlpha',.65,'edgecolor',...
    'none','FaceColor','interp','CDataMode','auto')
set(gcf,'renderer','opengl');
hold on
phrHnd=pcolor(reBnd, imBnd, intCntT);
set(phrHnd,'edgecolor','none') 
phrHnd.ZData=ones(size(intCntT)) * -max(max(intCnt));
grid off
colormap(hot) % heat map
view(3); %to view in 3D

figure;
phrHnd=pcolor(reBnd, imBnd, intCntT);
set(phrHnd,'edgecolor','none') 

clear('imBnd','reBnd','imPrt','rePrt','imRePrt',...
    'intCnt','intCntT','minIm','minRe','maxRe','maxIm','phrHnd')