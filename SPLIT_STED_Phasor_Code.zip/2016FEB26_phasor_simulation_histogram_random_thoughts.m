% for i=1:64
%     hist3([sPnStedRe(:,i,2), sPnStedIm(:,i,2)],[64 64]);
%     hold on;
%     set(gcf,'renderer','opengl');
%     set(get(gca,'child'),'FaceColor','interp','CDataMode','auto');
% end
% imSz=64;
% phrSz=100;

minRe=min(min(sPnStedRe(:,:,2)));
maxRe=max(max(sPnStedRe(:,:,2)));
minIm=min(min(sPnStedIm(:,:,2)));
maxIm=max(max(sPnStedIm(:,:,2)));

reStp=(maxRe-minRe)/phrSz;
imStp=(maxIm-minIm)/phrSz;

rePrt=reshape(sPnStedRe(:,:,2),[imSz*imSz,1]);
imPrt=reshape(sPnStedIm(:,:,2),[imSz*imSz,1]);
imRePrt=[rePrt, imPrt];

intCnt = hist3(imRePrt, [64,64]); % default is to 10x10 bins
intCntT = intCnt';
intCntT(size(intCnt,1) + 1, size(intCnt,2) + 1) = 0;

reBnd = linspace(minRe,maxRe,size(intCnt,1)+1);
imBnd = linspace(minIm,maxIm,size(intCnt,1)+1);

hist3(imRePrt, [64,64],'FaceAlpha',.65,'edgecolor',...
    'none','FaceColor','interp','CDataMode','auto')
set(gcf,'renderer','opengl');
hold on
phrHnd=pcolor(reBnd, imBnd, intCntT);
set(phrHnd,'edgecolor','none') 
phrHnd.ZData=ones(size(intCntT)) * -max(max(intCnt));
grid off
colormap(hot) % heat map
view(3);


