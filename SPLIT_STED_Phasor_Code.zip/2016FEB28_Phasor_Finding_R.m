%intesity function 
intst=@(time,r1,r2, gamma0, kSat, bmWst)(exp(-gamma0*time)./(1+kSat*gamma0*time/2).*...
    (exp(-(1+kSat*gamma0*time/2)*2*r1^2/bmWst^2)-...
     exp(-(1+kSat*gamma0*time/2)*2*r2^2/bmWst^2))...
    );
%find the r when int(F, r1:r2)=int(f, 0, inf)/(number of components)
rBndTmp=0; rBnd=0; rBnd(1)=0;
for k=1:iniPrm.nCmp-1
    for i=1:floor(iniPrm.bmWst/iniPrm.rPxSz)
        r1=rBndTmp;
        r2=r1+(i-1)*iniPrm.rPxSz;
        intstInt(i)=trapz(time, intst(time,r1,r2, iniPrm.gamma0, iniPrm.kSat, iniPrm.bmWst))-...
            (1/iniPrm.nCmp)*trapz(time, intst(time,0,inf, iniPrm.gamma0, iniPrm.kSat, iniPrm.bmWst));
    end
    [rMnVl rMnInd]=min(abs(intstInt));
    rBnd(k+1)=rBndTmp+rMnInd*iniPrm.rPxSz;
    rBndTmp=rBnd(k+1);
end
rBnd(end+1)=inf;
clear('k', 'i', 'rBndTmp', 'r1', 'r2', 'rMnInd', 'rMnVl','intstInt')

