%Define constants
sgnCnt=100000; %maximum counts
bmWst=167; %Beam waist
tau0=2.5; %lifetime
gamma0=1/tau0;
kSat=10; %I_STED/I_Saturation Ratio
nCmp=6; %number of component
nHrm=nCmp-1; %number of harmonics
pxSz=5.2; %Pixel Size
imSz=64; %Image size
tmMx=12.5;%Maximum time interval
nTmLp=128;%number of time laps 

%temporal steps
time=linspace(0,tmMx,nTmLp);
% for t=1:128
% time(t)=(t-1)*12.5/128;
% end
% clear('t');

%Generate only two particle in the center with the certain distance
sPn=zeros(64);
sPn(32, 23)=1;
sPn(32, 41)=1;

% %Generate random particles
% sPn=zeros(64);
% for i=1:64
%     for j=1:64
%         if rand()>0.9991
%             sPn(i,j)=1;
%         end
%     end
% end
% clear('i','j')

%count the number of particles in the simulated image
pnInd=0;
k=1;
for i=1:64
    for j=1:64
        if sPn(i,j)==1
            pnInd(k,1)=i;
            pnInd(k,2)=j;
            k=k+1;
        end
    end
end
clear('k','i','j')

%Convolution part, creates a stack of temporal spatial convolution of the
%image
sPnSted=zeros(imSz,imSz,nTmLp);
for t=1:nTmLp
    for k=1:size(pnInd,1)
        for i=1:64
            for j=1:64
                r=sqrt((pnInd(k,1)-i)^2+(pnInd(k,2)-j)^2)*pxSz;
                gamma(i,j)=gamma0*(1+kSat*r^2/bmWst^2);
                sPnStedTemp(i,j,t)=...
                    sgnCnt*exp(-2*r^2/bmWst^2)*...
                    exp(-gamma(i,j)*time(t));
            end
        end
        sPnSted(:,:,t)=sPnSted(:,:,t) + sPnStedTemp(:,:,t);
    end
end
clear('sPnStedTemp','t','k','i','j','r');

%View the generated stack
% ViewImageStack(sPnSted)

%Generating the STED Image
% imtool(sum(sPnSted, 3))

%calculate the real part and imaginary part of temeporal profile
%the 3rd dimentions indexes the higher harmonics of the fuorier transform.
sPnStedRe=zeros(imSz,imSz,nTmLp);
sPnStedIm=zeros(imSz,imSz,nTmLp);
% for k=1:nHrm
    for i=1:imSz
        for j=1:imSz
%             rePrt=real(fft(squeeze(sPnSted(i,j,:))));
%             imPrt=imag(fft(squeeze(sPnSted(i,j,:))));
            sPnStedRe(i,j,:)=real(fft(squeeze(sPnSted(i,j,:))))/...
                abs(sum(squeeze(sPnSted(i,j,:))));
            sPnStedIm(i,j,:)=imag(fft(squeeze(sPnSted(i,j,:))))/...
                abs(sum(squeeze(sPnSted(i,j,:))));
        end
    end
% end
clear('rePrt','imPrt','i','j','k');

%pxTmPrf=Pixel Temporal Profile
%grnd: Integrand 
%calculate the real part and imaginary part of temeporal profile by using
%analytical Sine and Cosine NOT FFT.
% for i=1:64
%    for j=1:64
%        pxTmPrf=squeeze(sPnSted(i,j,:)).';
%        grndRe=pxTmPrf.*cos(2*pi*time/max(time));
%        grndIm=pxTmPrf.*sin(2*pi*time/max(time));
%        sPnStedRe(i,j)=trapz(time, grndRe)/trapz(time,pxTmPrf);
%        sPnStedIm(i,j)=trapz(time, grndIm)/trapz(time,pxTmPrf);
%    end
% end
% clear('pxTmPrf','grndRe','grndIm')

%Plot the imaginary part vs the Real part (Phasor Plot)
% for j=1:floor((nCmp+1)/2)
    
for i=1:imSz
    plot(sPnStedRe(:,i,2), sPnStedIm(:,i,2),'.b');
    hold on;
end
    figure(1);
    title('Phasor Plot of the 1st harmonic')
    xlabel('Real')
    ylabel('Imaginary')
% end
clear('i','j');


%Temporal average 
for i=1:imSz
    for j=1:imSz
        sPnStedSm(i,j)=sum(sPnSted(i,j,:));
    end
end
clear('i','j')

%time integrated intensity
% for i=1:64
%     for j=1:64
%         pxTmPrf=squeeze(sPnSted(i,j,:)).';
%         sPnStedInt(i,j)=trapz(time,pxTmPrf);
%     end
% end
% clear('i','j','pxTmPrf')



%Vector P made of real and imaginary parts of various harmonics 
%[g   s   gh2   sh2 ...] every element of this vector is an image in
%reciprocal space
for i=1:floor((nCmp+1)/2)
    phsr(2*i-1,:,:)=sPnStedRe(:,:,i+1);
    phsr(2*i,:,:)=sPnStedIm(:,:,i+1);
end
clear('i')
if mod(nCmp,2)
    phsr=phsr(1:end-1, :,:)
end


%building the reconstruction matrix
%Matrix M for the known number of component in the temporal dynamics
%[g1   g2   g3   ...]
%[s1   s2   s3   ...]
%[g1h2 g2h2 g3h2 ...]
%[s1h2 s2h2 s3h2 ...]
%....
%g=real part, s1=imaginary part
for i=1:nCmp
   cmpFft(i,:)=fft(intst(time,rBnd(i),rBnd(i+1), gamma0, kSat, bmWst))./...
       abs(sum(intst(time,rBnd(i),rBnd(i+1), gamma0, kSat, bmWst)));
end
clear('i')
for i=1:floor((nCmp+1)/2)
    for j=1:nCmp
        cmpMtx(2*i-1,j)=real(cmpFft(j,i+1));
        cmpMtx(2*i,j)=imag(cmpFft(j,i+1));
    end
end
clear('i','j')
if mod(nCmp,2)
    cmpMtx=cmpMtx(1:end-1, :);
end


%Reconstructing the images related to each component
cmpMtxInv=inv(cmpMtx);
sPnStedRc=zeros(size(cmpMtx,1),imSz,imSz);
for k1=1:size(cmpMtx,1)
    for k2=1:size(cmpMtx,1)
        sPnStedRcTmp(k1,:,:)=cmpMtxInv(k1,k2)*squeeze(phsr(k2,:,:)).*...
            sPnStedSm(:,:);
        sPnStedRc(k1,:,:)=sPnStedRc(k1,:,:)+sPnStedRcTmp(k1,:,:);
    end
end
clear('k1','k2','sPnStedRcTemp')


imtool(squeeze(sPnStedRc(1,:,:)))
% imtool(squeeze(sPnStedRc(8,:,:)))
% imtool(squeeze(sPnStedRc(6,:,:)))
