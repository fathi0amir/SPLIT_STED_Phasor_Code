%Separate Photons by LIfetime Tuning (SPLIT) 
S=10^5;%S is the maximum intensity signal from a particle expressed 
       %in counts detected at one pixel in one frame of the stack.
Ks=10; %Isted/Isat
tau=2.5; %fluorescence lifetime in nanosecond
gamma0=1/tau; %decay rate without a STED beam
fwhm=167; %Full width of half maximum in nanometer for PSF
pixsize=5.2; %pixel size in nanometer
time=linspace(0,12.5,128); %time points

%Set up the parameters for Poisson noise
p=0;%'p=0' is to disable the Poisson noise; other than that is to enable Poisson noise
lambda_poiss=0.01*S; %lambda_poiss is the mean value of Poisson noise

%It is the time-dependent decay from r=0 to r=Inf
It=(exp(-gamma0*time)./(1+Ks*gamma0*time/2)).*...
   (exp(-(1+Ks*gamma0*time/2)*2*0^2/fwhm^2)...
   -exp(-(1+Ks*gamma0*time/2)*2*Inf^2/fwhm^2));

res=trapz(time,It); % Time-integrated intensity
n=10; % Number of temporal dynamics
weW=res/n; % This determines the area of each concentric ring

% Generate a point-like image for multiple particles
kk=1;
pp=zeros(64);
pp(32,23)=1;
pp(32,41)=1;
% pp(23,32)=1;
% pp(41,32)=1;
for i=1:size(pp,1)
    for j=1:size(pp,1)
        if pp(i,j)==1
        A(kk,1)=i;A(kk,2)=j;
        kk=kk+1;
        end
    end
end

%Finding the boundaries for n components
r1=0;
r_temp=0;
rr=zeros(1,n+1);
temp(1)=weW;
rr(1)=0;
rr(n+1)=Inf;
for j=1:size(rr,2)-2
    rr(j+1)=r_temp;
    for i=1:10001
    r1=i*0.01+rr(j+1);
    It=(exp(-gamma0*time)./(1+Ks*gamma0*time/2)).*...
       (exp(-(1+Ks*gamma0*time/2)*2*rr(j+1)^2/fwhm^2)-exp(-(1+Ks*gamma0*time/2)*2*r1^2/fwhm^2));
    temp(i+1)=abs(trapz(time,It)-weW);
        if temp(i+1)>temp(i)
           break
        end
    end
    r_temp=r1;
    rr(j+1)=r1-0.01;
end
% Show the boundary radius
for i=1:n+1
    rr(i)
end

% Temporal decays for n components
IIt=zeros(n,size(time,2));
for i=1:n
    IIt(i,:)=exp(-gamma0*time)./(1+Ks*gamma0*time/2).*(exp(-(1+Ks*gamma0*time./2)*2*rr(i)^2/fwhm^2)...
    -exp(-(1+Ks*gamma0*time./2)*2*rr(i+1)^2/fwhm^2));
end

% Generate a M matrix for SPLIT analysis
Mp=zeros(n);
for i=1:n
    if i<=2
      if mod(i,2)~=0
         for j=1:n   
             Mp(i,j)=trapz(time,IIt(j,:).*cos(2*pi*time/max(time)))/trapz(time,IIt(j,:));
         end
      else
        for j=1:n 
        Mp(i,j)=trapz(time,IIt(j,:).*sin(2*pi*time/max(time)))/trapz(time,IIt(j,:));
        end
      end  
    else
      if mod(i,2)~=0
        for j=1:n
             Mp(i,j)=trapz(time,IIt(j,:).*cos(2*pi*(i+1)/2*time/max(time)))/trapz(time,IIt(j,:));
        end
      else
        for j=1:n
             Mp(i,j)=trapz(time,IIt(j,:).*sin(2*pi*(i/2)*time/max(time)))/trapz(time,IIt(j,:));
        end 
      end  
    end     
end

% Generate the Poisson noise
poissnoise=zeros(size(pp,1),size(pp,2),size(time,2));
if p==0
   poissnoise=zeros(size(pp,1),size(pp,2),size(time,2));
else
for k=1:size(time,2)
    poissnoise(:,:,k)=poissrnd(lambda_poiss,size(pp,1),size(pp,2));
end
end

% Simulate the time-gated STED image before SPLIT analysis
imagestack=zeros(size(pp,1),size(pp,2),size(time,2));
imagestacktemp=zeros(size(pp,1),size(pp,2),size(time,2));
gamma=zeros(size(pp,1),size(pp,2));
for k=1:size(time,2)
    for m=1:size(A,1)
        for i=1:size(pp,1)
            for j=1:size(pp,2)
                r=sqrt((A(m,1)-i)^2+(A(m,2)-j)^2)*pixsize;
                gamma(i,j)=gamma0*(1+Ks*r^2/fwhm^2);
                imagestacktemp(i,j,k)=S*exp(-2*r^2/fwhm^2)*exp(-gamma(i,j)*time(k));
            end
        end
        imagestack(:,:,k)=imagestacktemp(:,:,k)+imagestack(:,:,k);
    end
    imagestack(:,:,k)=imagestack(:,:,k)+poissnoise(:,:,k);
end

% Generate a phase column vector 
phasevec=zeros(size(pp,1),size(pp,2),n);
imageg=zeros(size(pp,1),size(pp,2),size(time,2));
images=zeros(size(pp,1),size(pp,2),size(time,2));
 for k=1:n
     if mod(k,2)~=0
        for t=1:size(time,2)
             imageg(:,:,t)=imagestack(:,:,t)*cos(2*pi*((k+1)/2)*time(t)/max(time));
        end
     phasevec(:,:,k)=trapz(imageg,3)./trapz(imagestack,3);
     else
        for t=1:size(time,2)
             images(:,:,t)=imagestack(:,:,t)*sin(2*pi*((k)/2)*time(t)/max(time));
        end
     phasevec(:,:,k)=trapz(images,3)./trapz(imagestack,3);
    end
end   

% Plot a phasor plot for the first component
for i=1:size(pp,1)
    plot(phasevec(:,i,1),phasevec(:,i,2),'r.');hold on; axis equal;
end

% Create a time-integrated image for time-gated STED images--This is
% equivalent to the conventional STED image
N=zeros(size(pp,1),size(pp,2));
for i=1:size(pp,1)
    for j=1:size(pp,2)
        N(i,j)=trapz(time,squeeze(imagestack(i,j,:)).');
    end
end

% Generate a inverse matrix of Mp
IMp=inv(Mp);

% Generate a SPLIT-assisted STED image stack
result=zeros(size(pp,1),size(pp,2),n);
finalimagestack=zeros(size(pp,1),size(pp,2),n);
for i=1:n
    for j=1:n
    result(:,:,i)=IMp(i,j)*phasevec(:,:,j)+result(:,:,i);
    end
    finalimagestack(:,:,i)=result(:,:,i).*N;
end

imtool(finalimagestack(:,:,1));


